# Simplex
 
In this library you can use simplex with steps. All the tables will be shown and all analysis will be available for your use. 
